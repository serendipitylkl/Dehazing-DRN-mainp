# Dehazing-DRN

**Datasets:** 

TrainA-TestA

https://drive.google.com/drive/folders/1Qv7SIZBVAtb9G1d6iVKu_8rVSsXJdv26?usp=sharing

https://drive.google.com/drive/folders/1hbwYCzoI3R3o2Gj_kfT6GHG7RmYEOA-P?usp=sharing

RESIDE

https://sites.google.com/view/reside-dehaze-datasets/

**Pre_train models:**

RESIDE_Indoor: https://pan.baidu.com/s/13r2bvI7EmcxNo0wTNIpotA (9b12) 


RESIDE_Outdoor: https://pan.baidu.com/s/1VcucaQPpQ-2sa1w5WwckUQ (sc5d) 

TrainA-TestA: https://pan.baidu.com/s/1JKgn26X7R6k0Rli4UXQeiA (6ipa) 




